﻿using Library;
using System;

namespace ConsoleApp
{
    class Program
    {
        static void Main (string[] args)
        {
            // Базовый класс
            Nutrition nutrition = new Nutrition("Куриная грудка", 24, 1);
            Console.WriteLine(nutrition.GetInfo());

            // Класс-наследник
            NutritionExtended extendedNutrition = new NutritionExtended("Куриная грудка", 24, 1, 165);
            Console.WriteLine(extendedNutrition.GetInfo());
        }
    }
}
