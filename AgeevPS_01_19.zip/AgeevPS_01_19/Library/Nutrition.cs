﻿using System;

namespace Library
{
    public class Nutrition
    {
        public string Name { get; set; } // Название продукта
        public int Protein { get; set; } // Количество белка
        public int Carbohydrates { get; set; } // Количество углеводов
        public Nutrition (string name, int protein, int carbohydrates) // Конструктор
        {
            Name = name;
            Protein = protein;
            Carbohydrates = carbohydrates;
        }
        public virtual double GetQ () // Качество продукта
        {
            return Carbohydrates * 4 + Protein * 4;
        }
        public string GetInfo () // Вывод информации
        {
            return $"Название продукта - {Name}\n" +
                   $"Количество белка - {Protein}г.\n" +
                   $"Количество углеводов - {Carbohydrates}г.\n" +
                   $"Q - {GetQ()}";
        }
    }
}
