﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library
{
    public class NutritionExtended :Nutrition
    {
        public int Calories { get; set; } // Калорийность
        public NutritionExtended (string name, int protein, int carbohydrates, int calories) : base(name, protein, carbohydrates) // Конструктор
        {
            Calories = calories;
        }
        public override double GetQ () // Качество продукта
        {
            return base.GetQ() * 1.2 + Calories * 7;
        }
    }
}
